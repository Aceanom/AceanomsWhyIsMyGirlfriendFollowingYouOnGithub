---
name: Enhancement
about: Suggest an enhancement to step-ca
title: ''
labels: enhancement, needs triage
assignees: ''

---

## Hello!
<!-- Please leave this section as-is, 
it's designed to help others in the community know how to interact with our GitHub issues. -->

- Vote on this issue by adding a 👍 reaction
- If you want to implement this feature, comment to let us know (we'll work with you on design, scheduling, etc.)

## Issue details

<!-- Enhancement requests are most helpful when they describe the problem you're having 
as well as articulating the potential solution you'd like to see built. -->

## Why is this needed?

<!-- Let us know why you think this enhancement would be good for the project or community. -->
