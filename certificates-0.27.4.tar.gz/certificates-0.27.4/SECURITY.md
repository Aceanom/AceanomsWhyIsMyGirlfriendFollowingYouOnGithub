We appreciate any effort to discover and disclose security vulnerabilities responsibly.

If you would like to report a vulnerability in one of our projects, or have security concerns regarding Smallstep software, please email security@smallstep.com.

In order for us to best respond to your report, please include any of the following:
 * Steps to reproduce or proof-of-concept
 * Any relevant tools, including versions used
 * Tool output
