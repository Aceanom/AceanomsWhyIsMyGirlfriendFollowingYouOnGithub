---
name: Documentation Request
about: Request documentation for a feature
title: '[Docs]:'
labels: docs, needs triage
assignees: ''

---

## Hello!
<!-- Please leave this section as-is, it's designed to help others in the community know how to interact with our GitHub issues. -->

- Vote on this issue by adding a 👍 reaction
- If you want to document this feature, comment to let us know (we'll work with you on design, scheduling, etc.)

## Affected area/feature

<!---
Tell us which feature you'd like to see documented. 
 - Where would you like that documentation to live (command line usage output, website, github markdown on the repo)? 
- If there are specific attributes or options you'd like to see documented, please include those in the request.
-->
