# Scripts folder

Please note that `install-step-ra.sh` is referenced on the `files.smallstep.com` S3 website bucket as a redirect to `raw.githubusercontent.com`. If you move it, please update the S3 redirect.

## badger-migration

badger-migration is a tool that allows migrating data from BadgerDB (v1 or
v2) to MySQL or PostgreSQL.
