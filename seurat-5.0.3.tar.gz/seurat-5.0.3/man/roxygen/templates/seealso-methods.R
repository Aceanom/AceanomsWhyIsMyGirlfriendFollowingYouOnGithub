#' @seealso \code{<%= cls %>} methods: \code{\link{<%= cls %>-methods}}
