# Contributors ✨

Thanks goes to these wonderful people ([emoji key](https://allcontributors.org/docs/en/emoji-key)):

<!-- ALL-CONTRIBUTORS-LIST:START - Do not remove or modify this section -->
<!-- prettier-ignore-start -->
<!-- markdownlint-disable -->
<table>
  <tr>
    <td align="center"><a href="https://github.com/gaborcsardi"><img src="https://avatars.githubusercontent.com/u/660288?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Gábor Csárdi</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=gaborcsardi" title="Code">💻</a></td>
    <td align="center"><a href="https://collmot.com/"><img src="https://avatars.githubusercontent.com/u/195637?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Tamás Nepusz</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=ntamas" title="Code">💻</a></td>
    <td align="center"><a href="http://szhorvat.net/"><img src="https://avatars.githubusercontent.com/u/1212871?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Szabolcs Horvát</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=szhorvat" title="Code">💻</a></td>
    <td align="center"><a href="http://www.traag.net/"><img src="https://avatars.githubusercontent.com/u/6057804?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Vincent Traag</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=vtraag" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/GroteGnoom"><img src="https://avatars.githubusercontent.com/u/8137208?v=4?s=100" width="100px;" alt=""/><br /><sub><b>GroteGnoom</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=GroteGnoom" title="Code">💻</a></td>
    <td align="center"><a href="https://fabilab.org/"><img src="https://avatars.githubusercontent.com/u/1200640?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Fabio Zanini</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=iosonofabio" title="Code">💻</a></td>
    <td align="center"><a href="http://www.katzien.de/"><img src="https://avatars.githubusercontent.com/u/890156?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Jan Katins</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=jankatins" title="Code">💻</a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://github.com/adalisan"><img src="https://avatars.githubusercontent.com/u/1790714?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Sancar Adali</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=adalisan" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/FerranPares"><img src="https://avatars.githubusercontent.com/u/9196604?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Ferran Parés</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=FerranPares" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/mvngu"><img src="https://avatars.githubusercontent.com/u/362259?v=4?s=100" width="100px;" alt=""/><br /><sub><b>mvngu</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=mvngu" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/das-intensity"><img src="https://avatars.githubusercontent.com/u/12521554?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Dr. Nick</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=das-intensity" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/jannick0"><img src="https://avatars.githubusercontent.com/u/6295579?v=4?s=100" width="100px;" alt=""/><br /><sub><b>jannick0</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=jannick0" title="Code">💻</a></td>
    <td align="center"><a href="https://www.rezozer.net/"><img src="https://avatars.githubusercontent.com/u/8476716?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Jérôme Benoit</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=jgmbenoit" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/frederik-h"><img src="https://avatars.githubusercontent.com/u/22046314?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Frederik Harwath</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=frederik-h" title="Code">💻</a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://adalogics.com/"><img src="https://avatars.githubusercontent.com/u/44787359?v=4?s=100" width="100px;" alt=""/><br /><sub><b>AdamKorcz</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=AdamKorcz" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/antonio-rojas"><img src="https://avatars.githubusercontent.com/u/11243355?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Antonio Rojas</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=antonio-rojas" title="Code">💻</a></td>
    <td align="center"><a href="https://pyedu.hu/arpad/"><img src="https://avatars.githubusercontent.com/u/951303?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Árpád Horváth</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=horvatha" title="Code">💻</a></td>
    <td align="center"><a href="http://finger-tree.blogspot.com/"><img src="https://avatars.githubusercontent.com/u/406445?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Peter Scott</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=PeterScott" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/naviddianati"><img src="https://avatars.githubusercontent.com/u/5558232?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Navid Dianati</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=naviddianati" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/YasirKusay"><img src="https://avatars.githubusercontent.com/u/59812220?v=4?s=100" width="100px;" alt=""/><br /><sub><b>YasirKusay</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=YasirKusay" title="Code">💻</a></td>
    <td align="center"><a href="http://heal.heuristiclab.com/team/beham"><img src="https://avatars.githubusercontent.com/u/5585242?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Andreas Beham</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=abeham" title="Code">💻</a></td>
  </tr>
  <tr>
    <td align="center"><a href="http://kasterma.net/"><img src="https://avatars.githubusercontent.com/u/421437?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Bart Kastermans</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=kasterma" title="Code">💻</a></td>
    <td align="center"><a href="https://twitter.com/eriknwelch"><img src="https://avatars.githubusercontent.com/u/2058401?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Erik Welch</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=eriknw" title="Code">💻</a></td>
    <td align="center"><a href="https://www.topbug.net/"><img src="https://avatars.githubusercontent.com/u/325476?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Hong Xu</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=xuhdev" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/Hosseinazari"><img src="https://avatars.githubusercontent.com/u/971459?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Hosseinazari</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=Hosseinazari" title="Code">💻</a></td>
    <td align="center"><a href="https://jmonlong.github.io/"><img src="https://avatars.githubusercontent.com/u/5704457?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Jean Monlong</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=jmonlong" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/Keivin98"><img src="https://avatars.githubusercontent.com/u/31882637?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Keivin98</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=Keivin98" title="Code">💻</a></td>
    <td align="center"><a href="https://araujo88.medium.com/"><img src="https://avatars.githubusercontent.com/u/46436462?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Leonardo de Araujo</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=araujo88" title="Code">💻</a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://github.com/msk"><img src="https://avatars.githubusercontent.com/u/19195?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Min Kim</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=msk" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/khitrin"><img src="https://avatars.githubusercontent.com/u/25713847?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Nikolay Khitrin</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=khitrin" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/pschmied"><img src="https://avatars.githubusercontent.com/u/1065905?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Peter Schmiedeskamp</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=pschmied" title="Code">💻</a></td>
    <td align="center"><a href="https://phil.red/"><img src="https://avatars.githubusercontent.com/u/291575?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Philipp A.</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=flying-sheep" title="Code">💻</a></td>
    <td align="center"><a href="https://www.linkedin.com/in/ramy-saied-0415b810b/"><img src="https://avatars.githubusercontent.com/u/22375919?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Ramy Saied</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=RamySaied1" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/dotlambda"><img src="https://avatars.githubusercontent.com/u/6806011?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Robert Schütz</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=dotlambda" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/ryanduffin"><img src="https://avatars.githubusercontent.com/u/5711508?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Ryan Duffin</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=ryanduffin" title="Code">💻</a></td>
  </tr>
  <tr>
    <td align="center"><a href="http://www.shlomifish.org/"><img src="https://avatars.githubusercontent.com/u/3150?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Shlomi Fish</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=shlomif" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/kloczek"><img src="https://avatars.githubusercontent.com/u/31284574?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Tomasz Kłoczko</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=kloczek" title="Code">💻</a></td>
    <td align="center"><a href="https://heavywatal.github.io/"><img src="https://avatars.githubusercontent.com/u/1431267?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Watal M. Iwasaki</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=heavywatal" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/nograpes"><img src="https://avatars.githubusercontent.com/u/2967973?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Aman Verma</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=nograpes" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/guyroznb"><img src="https://avatars.githubusercontent.com/u/55619320?v=4?s=100" width="100px;" alt=""/><br /><sub><b>guy rozenberg</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=guyroznb" title="Code">💻</a></td>
    <td align="center"><a href="http://linkedin.com/in/artemvl"><img src="https://avatars.githubusercontent.com/u/6162969?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Artem V L</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=luav" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/Katterrina"><img src="https://avatars.githubusercontent.com/u/31630249?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Kateřina Č.</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=Katterrina" title="Code">💻</a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://github.com/valdaarhun"><img src="https://avatars.githubusercontent.com/u/39989901?v=4?s=100" width="100px;" alt=""/><br /><sub><b>valdaarhun</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=valdaarhun" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/YuliYudith"><img src="https://avatars.githubusercontent.com/u/54366258?v=4?s=100" width="100px;" alt=""/><br /><sub><b>YuliYudith</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=YuliYudith" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/alexsyou"><img src="https://avatars.githubusercontent.com/u/54590871?v=4?s=100" width="100px;" alt=""/><br /><sub><b>alexsyou</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=alexsyou" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/rohitt28"><img src="https://avatars.githubusercontent.com/u/67415747?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Rohit Tawde</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=rohitt28" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/alexperrone"><img src="https://avatars.githubusercontent.com/u/4990236?v=4?s=100" width="100px;" alt=""/><br /><sub><b>alexperrone</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=alexperrone" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/borsgeorgica"><img src="https://avatars.githubusercontent.com/u/15649138?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Georgica Bors</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=borsgeorgica" title="Code">💻</a></td>
    <td align="center"><a href="https://www.linkedin.com/in/meet-patel-b1329a16b/"><img src="https://avatars.githubusercontent.com/u/63169740?v=4?s=100" width="100px;" alt=""/><br /><sub><b>MEET PATEL</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=meetpatel0963" title="Code">💻</a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://github.com/kwofach"><img src="https://avatars.githubusercontent.com/u/97578264?v=4?s=100" width="100px;" alt=""/><br /><sub><b>kwofach</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=kwofach" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/Gomango999"><img src="https://avatars.githubusercontent.com/u/37771462?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Kevin Zhu</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=Gomango999" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/pradkrish"><img src="https://avatars.githubusercontent.com/u/47261443?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Pradeep Krishnamurthy</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=pradkrish" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/flange-ipb"><img src="https://avatars.githubusercontent.com/u/34936695?v=4?s=100" width="100px;" alt=""/><br /><sub><b>flange-ipb</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=flange-ipb" title="Code">💻</a></td>
    <td align="center"><a href="http://goo.gl/IlWG8U"><img src="https://avatars.githubusercontent.com/u/500?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Juan Julián Merelo Guervós</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=JJ" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/rfulekjames"><img src="https://avatars.githubusercontent.com/u/54232342?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Radoslav Fulek</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=rfulekjames" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/professorcode1"><img src="https://avatars.githubusercontent.com/u/42749164?v=4?s=100" width="100px;" alt=""/><br /><sub><b>professorcode1</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=professorcode1" title="Code">💻</a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://github.com/larah19"><img src="https://avatars.githubusercontent.com/u/54937363?v=4?s=100" width="100px;" alt=""/><br /><sub><b>larah19</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=larah19" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/Biswa96"><img src="https://avatars.githubusercontent.com/u/31443074?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Biswapriyo Nath</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=Biswa96" title="Code">💻</a></td>
    <td align="center"><a href="http://cecinestpasunefromage.wordpress.com/"><img src="https://avatars.githubusercontent.com/u/2363820?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Gwyn Ciesla</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=limburgher" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/aagon"><img src="https://avatars.githubusercontent.com/u/10883752?v=4?s=100" width="100px;" alt=""/><br /><sub><b>aagon</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=aagon" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/GanzuraTheConsumer"><img src="https://avatars.githubusercontent.com/u/19657136?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Quinn Buratynski</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=GanzuraTheConsumer" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/Tagl"><img src="https://avatars.githubusercontent.com/u/7704746?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Arnar Bjarni Arnarson</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=Tagl" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/SoapGentoo"><img src="https://avatars.githubusercontent.com/u/16636962?v=4?s=100" width="100px;" alt=""/><br /><sub><b>David Seifert</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=SoapGentoo" title="Code">💻</a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://fosstodon.org/@kirill"><img src="https://avatars.githubusercontent.com/u/1741643?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Kirill Müller</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=krlmlr" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/gendelpiekel"><img src="https://avatars.githubusercontent.com/u/14215028?v=4?s=100" width="100px;" alt=""/><br /><sub><b>Michael</b></sub></a><br /><a href="https://github.com/igraph/igraph/commits?author=gendelpiekel" title="Code">💻</a></td>
  </tr>
</table>

<!-- markdownlint-restore -->
<!-- prettier-ignore-end -->

<!-- ALL-CONTRIBUTORS-LIST:END -->

This project follows the [all-contributors](https://github.com/all-contributors/all-contributors) specification. Contributions of any kind welcome!
