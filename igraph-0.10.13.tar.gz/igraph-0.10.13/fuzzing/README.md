The fuzzing infrastructure of igraph is located in this directory.

The fuzzers are run continuously through OSS-fuzz.

The `build.sh` script is used by OSS-fuzz to build the fuzzers on their platform.
