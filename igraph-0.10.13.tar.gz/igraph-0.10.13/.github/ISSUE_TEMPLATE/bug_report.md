---
name: Bug report
about: Report a problem in the igraph C library
title: ''
labels: ''
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**To reproduce**
Steps or minimal example code to reproduce the problem.

**Version information**
Which version of igraph are you using and where did you obtain it?
