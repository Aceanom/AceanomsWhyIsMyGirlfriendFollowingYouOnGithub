Reporting issues
================

We use the issue tracker for tracking bugs and feature requests _only_.
If you do not have a bug or feature request but you only need help with using
igraph, send your question to the igraph-help mailing list instead at
igraph-help@nongnu.org.
