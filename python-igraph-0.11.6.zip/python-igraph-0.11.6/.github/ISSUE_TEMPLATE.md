Make sure that these boxes are checked before submitting your issue -- thank you!

- [ ] This issue is for the Python interface of igraph.
- [ ] This issue is a bug report or a feature request, not a support question.
