library(testthat)
library(sctransform)

test_check("sctransform")
