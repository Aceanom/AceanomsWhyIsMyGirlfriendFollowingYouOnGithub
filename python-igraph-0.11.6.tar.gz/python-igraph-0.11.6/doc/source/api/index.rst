.. include:: ../include/global.rst

.. currentmodule:: igraph


API reference
=============
