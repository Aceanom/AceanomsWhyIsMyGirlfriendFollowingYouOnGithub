.. _gallery-of-examples:

Gallery of Examples
===================

Gallery of examples for `python-igraph` illustrating graph generation, analysis, and plotting.

Impatient? Check out the :ref:`tutorials-quickstart`.

Too little detail? Read the :doc:`extended tutorial <../tutorial>`.
